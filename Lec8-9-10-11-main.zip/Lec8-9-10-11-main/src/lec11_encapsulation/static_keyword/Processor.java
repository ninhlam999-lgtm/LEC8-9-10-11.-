package lec11_encapsulation.static_keyword;

public class Processor {
    public static void main(String[] args) {
        new Counter();
        new Counter();
        new Counter();
    }
}
