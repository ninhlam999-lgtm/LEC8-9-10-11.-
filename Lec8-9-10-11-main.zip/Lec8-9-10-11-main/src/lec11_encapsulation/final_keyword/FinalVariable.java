package lec11_encapsulation.final_keyword;

public class FinalVariable {
    final int MAX = 100;

    void display() {
        System.out.println(MAX);
    }
}
