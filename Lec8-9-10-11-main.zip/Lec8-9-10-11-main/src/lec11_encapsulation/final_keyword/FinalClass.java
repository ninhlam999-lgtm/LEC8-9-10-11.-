package lec11_encapsulation.final_keyword;

final class A {
    void show() {
        System.out.println("Final class");
    }
}
