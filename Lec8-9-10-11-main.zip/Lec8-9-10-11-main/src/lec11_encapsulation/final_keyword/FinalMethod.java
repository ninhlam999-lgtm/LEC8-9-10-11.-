package lec11_encapsulation.final_keyword;

class A {
    final void show() {
        System.out.println("Final method");
    }
}

class B extends A {
}
