package lec11_encapsulation.access_modifier.different_package.test1;

public class AccessModifier1 {
    private int pvt = 1;
    int df = 2;
    protected int pro = 3;
    public int pbl = 4;
}
