package lec11_encapsulation.access_modifier.same_package;

public class AccessModifier2 extends AccessModifier1 {
    public void display() {
        System.out.println(df);
        System.out.println(pro);
        System.out.println(pbl);
    }
}
