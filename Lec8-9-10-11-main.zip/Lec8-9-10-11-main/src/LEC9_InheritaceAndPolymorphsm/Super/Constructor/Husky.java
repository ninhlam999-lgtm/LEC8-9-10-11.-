package LEC9_InheritaceAndPolymorphsm.Super.Constructor;

public class Husky extends Dog {

    Husky() {
        super();
        System.out.println("Husky's constructor is invoked");
    }
}
