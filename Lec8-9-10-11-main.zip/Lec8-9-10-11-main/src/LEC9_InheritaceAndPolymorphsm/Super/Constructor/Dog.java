
package LEC9_InheritaceAndPolymorphsm.Super.Constructor;

public class Dog {
  Dog(){
System.out.println("Dog's constructor is invoked");
}
  
}
