package LEC9_InheritaceAndPolymorphsm.Super.Constructor;

public class Processor {

    public static void main(String[] args) {
        Husky husky = new Husky();
    }

}
