
package LEC9_InheritaceAndPolymorphsm.Super.Runtimepolymorphism;
public class Animal {
   void makeSound() {
 System.out.println("dong vat nao phat ra am thanh nay ?");
 }
} 
    

