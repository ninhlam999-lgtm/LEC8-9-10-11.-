
package LEC9_InheritaceAndPolymorphsm.Super.Runtimepolymorphism;
class Dog extends Animal {
 @Override
 void makeSound() {
 System.out.println("GAU GAU");
 }
}