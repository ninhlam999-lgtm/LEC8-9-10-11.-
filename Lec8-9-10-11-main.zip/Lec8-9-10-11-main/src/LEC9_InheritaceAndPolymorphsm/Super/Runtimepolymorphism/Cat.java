
package LEC9_InheritaceAndPolymorphsm.Super.Runtimepolymorphism;
class Cat extends Animal {
 @Override
 void makeSound() {
 System.out.println("meo meo meo meo meo con meo ngu ngoc dang yeu cute pho mai que cua chi");
 }
}