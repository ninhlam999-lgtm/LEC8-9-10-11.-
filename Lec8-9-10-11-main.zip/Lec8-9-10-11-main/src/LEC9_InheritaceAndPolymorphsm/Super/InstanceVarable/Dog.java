package LEC9_InheritaceAndPolymorphsm.Super.InstanceVarable;

public class Dog {
    int price = 1000;
}
