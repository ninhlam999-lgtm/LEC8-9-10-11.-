package LEC9_InheritaceAndPolymorphsm.Super.methodoverriding;
class Animal {
    void makeSound() {
        System.out.println(" makes a sound");
    }
}

