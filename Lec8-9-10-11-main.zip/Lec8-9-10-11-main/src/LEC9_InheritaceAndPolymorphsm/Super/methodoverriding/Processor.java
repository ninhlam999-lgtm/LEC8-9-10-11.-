
package LEC9_InheritaceAndPolymorphsm.Super.methodoverriding;
public class Processor {
  public static void main(String[] args) {
Cat cat = new Cat();
cat.makeSound();
}
}