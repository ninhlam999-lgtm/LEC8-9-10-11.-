
package LEC9_InheritaceAndPolymorphsm.Super.methodoverriding;
public class Cat  extends Animal{
   
void makeSound() {
System.out.println("Meows meows");
}
  
}
