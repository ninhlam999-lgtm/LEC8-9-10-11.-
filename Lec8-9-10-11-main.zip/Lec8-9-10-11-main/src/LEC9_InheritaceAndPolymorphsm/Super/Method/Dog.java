
package LEC9_InheritaceAndPolymorphsm.Super.Method;

public class Dog {
void displayPrice(){
System.out.println("Dog's price is 1000 USD");
}
}