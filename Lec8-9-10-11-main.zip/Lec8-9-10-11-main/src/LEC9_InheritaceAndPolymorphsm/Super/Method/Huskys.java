package LEC9_InheritaceAndPolymorphsm.Super.Method;

public class Huskys extends Dog {
    void displayInformation() {
        super.displayPrice();
        System.out.println("Husky's price is 1500 USD");
    }}
