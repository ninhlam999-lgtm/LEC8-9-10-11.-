package LEC9_InheritaceAndPolymorphsm.Super.Method;

public class Processor {

    public static void main(String[] args) {
        Huskys husky = new Huskys();
        husky.displayInformation();
    }
}
