package LEC9_InheritaceAndPolymorphsm.Example1;

public class Cat {

    String catID = "cat";

    void catchMouse() {
        System.out.println("Catch the mouse");
    }

    void makeSound() {
        System.out.println("huydeptrai."); 
    }

}
