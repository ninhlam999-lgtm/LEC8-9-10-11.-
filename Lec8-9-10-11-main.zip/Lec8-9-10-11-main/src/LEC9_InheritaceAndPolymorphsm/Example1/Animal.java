package LEC9_InheritaceAndPolymorphsm.Example1;

public class Animal {

    String source = "Viet Nam";

    void makeSound() {
        System.out.println("Make a sound");
    }

}
