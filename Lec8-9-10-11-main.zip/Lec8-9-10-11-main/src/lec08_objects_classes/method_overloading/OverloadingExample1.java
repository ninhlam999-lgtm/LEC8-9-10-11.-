package lec08_objects_classes.method_overloading;

public class OverloadingExample1 {
    public static int add(int a, int b) {
        return a + b;
    }
    public static int add(int a, int b, int c) {
        return a + b + c;
    }
}
