package lec08_objects_classes.object_class;

public class Processor {
    public static void main(String[] args) {
        Car myCar = new Car("Lamborghini", 2020);
        myCar.displayDetails();
    }
}
