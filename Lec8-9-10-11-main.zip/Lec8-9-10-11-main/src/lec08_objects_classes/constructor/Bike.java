package lec08_objects_classes.constructor;

public class Bike {
    Bike() {
        System.out.println("Bike is created");
    }
}
