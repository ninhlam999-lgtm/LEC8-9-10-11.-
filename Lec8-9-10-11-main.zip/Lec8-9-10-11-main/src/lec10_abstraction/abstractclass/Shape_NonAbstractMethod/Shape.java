package lec10_abstraction.abstractclass.Shape_NonAbstractMethod;
public abstract class Shape {
    public void displayInfo() {
        System.out.println("This is a shape");
    }
}
