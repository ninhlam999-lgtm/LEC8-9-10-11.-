package lec10_abstraction.abstractclass.Shape_NonAbstractMethod;
public class Square extends Shape {}
