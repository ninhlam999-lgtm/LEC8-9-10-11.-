package lec10_abstraction.abstractclass.Shape_NonAbstractMethod;
public class Processor {
    public static void main(String[] args) {
        Square square = new Square();
        square.displayInfo();
    }
}
