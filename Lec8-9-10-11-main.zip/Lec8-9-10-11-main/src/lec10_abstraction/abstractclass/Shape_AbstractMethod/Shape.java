package lec10_abstraction.abstractclass.Shape_AbstractMethod;
public abstract class Shape {
    public abstract double calculateArea();
}
