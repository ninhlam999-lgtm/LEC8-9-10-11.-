package lec10_abstraction.interfaceexample.InterfaceExtend;
public interface IShape {
    void drawShape();
}
