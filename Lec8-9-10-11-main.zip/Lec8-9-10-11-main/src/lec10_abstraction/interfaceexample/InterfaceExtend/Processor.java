package lec10_abstraction.interfaceexample.InterfaceExtend;
public class Processor {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.drawShape();
        circle.fillColor();
    }
}
