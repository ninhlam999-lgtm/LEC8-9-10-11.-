package lec10_abstraction.interfaceexample.MultipleInheritance;
public interface IColor {
    void fillColor();
}
