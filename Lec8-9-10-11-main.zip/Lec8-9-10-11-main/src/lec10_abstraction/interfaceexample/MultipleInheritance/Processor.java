package lec10_abstraction.interfaceexample.MultipleInheritance;
public class Processor {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.drawShape();
        circle.fillColor();
    }
}
