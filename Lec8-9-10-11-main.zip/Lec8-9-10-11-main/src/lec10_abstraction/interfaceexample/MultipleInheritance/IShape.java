package lec10_abstraction.interfaceexample.MultipleInheritance;
public interface IShape {
    void drawShape();
}
