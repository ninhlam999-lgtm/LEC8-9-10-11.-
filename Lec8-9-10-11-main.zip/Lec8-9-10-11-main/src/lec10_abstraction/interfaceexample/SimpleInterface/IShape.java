package lec10_abstraction.interfaceexample.SimpleInterface;
public interface IShape {
    void drawShape();
}
