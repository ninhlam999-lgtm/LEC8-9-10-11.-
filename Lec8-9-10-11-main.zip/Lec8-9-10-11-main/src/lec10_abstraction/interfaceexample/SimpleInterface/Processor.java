package lec10_abstraction.interfaceexample.SimpleInterface;
public class Processor {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.drawShape();
    }
}
